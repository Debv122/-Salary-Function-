# ============================================================
# R Script: Unzip Employee Profile and Display Data
# Task 6 — SF Employee Salary Assignment
# ============================================================

zip_file    <- "Employee Profile.zip"
extract_dir <- "Employee_Profile_Extracted"

# Step 1: Check ZIP exists
if (!file.exists(zip_file)) {
  stop(paste("[ERROR] ZIP file not found:", zip_file,
             "\nPlease run Task 5 in the Jupyter Notebook first."))
}

# Step 2: Unzip
cat("Unzipping:", zip_file, "->", extract_dir, "\n")
unzip(zip_file, exdir = extract_dir)
cat("Done.\n\n")

# Step 3: List extracted CSVs
csv_files <- list.files(extract_dir, pattern = "\\.csv$",
                        full.names = TRUE, recursive = TRUE)
cat(sprintf("%d CSV file(s) found:\n", length(csv_files)))
for (f in csv_files) cat("  ", basename(f), "\n")
cat("\n")

if (length(csv_files) == 0) {
  message("[WARNING] No CSV files in the extracted folder.")
  quit(status = 1)
}

# Step 4: Display each profile
all_data <- list()
for (csv_path in csv_files) {
  cat("---", basename(csv_path), "---\n")
  emp <- read.csv(csv_path, stringsAsFactors = FALSE)
  for (col in colnames(emp)) {
    val <- emp[[col]][1]
    if (!is.na(val) && val != "") {
      cat(sprintf("  %-22s: %s\n", col, val))
    }
  }
  cat("\n")
  all_data[[basename(csv_path)]] <- emp
}

# Step 5: Combined summary
combined <- do.call(rbind, all_data)
rownames(combined) <- NULL
cat("=== Combined Summary Table ===\n")
print(combined[, c("name", "job_title", "year", "base_pay", "total_pay")])
